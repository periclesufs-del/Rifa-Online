# PPGCA/UFAM · Fluxo de Acompanhamento Discente

Arquivos para subir no GitHub:
- app.py
- requirements.txt
- README.md
- .gitignore
- secrets-example.toml

Não subir:
- .streamlit/secrets.toml
- arquivos .db
- __pycache__/
